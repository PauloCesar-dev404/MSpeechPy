from .api import get_access_token
from .voices import Voices
from .speech import SpeechText
