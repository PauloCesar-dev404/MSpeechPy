__version__ = '0.0.9'
__lib_name__ = 'MSpeechPy'
__autor__ = 'PauloCesar-dev404'
__repo__ = f'https://github.com/PauloCesar-dev404/{__lib_name__}'
